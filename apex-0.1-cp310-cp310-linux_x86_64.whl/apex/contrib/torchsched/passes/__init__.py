"""Customized compiler passes."""

from __future__ import annotations

from apex.contrib.torchsched.passes.pre_grad_passes import pre_grad_custom_pass

__all__ = ["pre_grad_custom_pass"]
